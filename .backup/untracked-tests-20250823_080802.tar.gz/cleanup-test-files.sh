#!/bin/zsh

# Cleanup script for test files
# Creates cleanup branch, archives untracked test files, updates .gitignore, generates tracked file list

set -e

# Generate timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR=".backup"
ARCHIVE_NAME="untracked-tests-${TIMESTAMP}.tar.gz"
TRACKED_LIST="tracked-test-files-${TIMESTAMP}.txt"

echo "🧹 Starting cleanup process..."
echo "Timestamp: ${TIMESTAMP}"

# Create backup directory if it doesn't exist
mkdir -p "${BACKUP_DIR}"

# Create cleanup branch
echo "📝 Creating cleanup branch..."
CURRENT_BRANCH=$(git branch --show-current)
CLEANUP_BRANCH="cleanup/test-files-${TIMESTAMP}"
git checkout -b "${CLEANUP_BRANCH}"
echo "✅ Created and switched to branch: ${CLEANUP_BRANCH}"

# Find untracked files with "test" in path
echo "🔍 Finding untracked files with 'test' in path..."
UNTRACKED_TEST_FILES=$(git ls-files --others --exclude-standard | grep -i test || true)

if [[ -n "${UNTRACKED_TEST_FILES}" ]]; then
    echo "📦 Found untracked test files to archive:"
    echo "${UNTRACKED_TEST_FILES}"
    
    # Create archive of untracked test files
    echo "${UNTRACKED_TEST_FILES}" | tar -czf "${BACKUP_DIR}/${ARCHIVE_NAME}" -T -
    echo "✅ Archived untracked test files to: ${BACKUP_DIR}/${ARCHIVE_NAME}"
    
    # Remove the untracked test files
    echo "${UNTRACKED_TEST_FILES}" | xargs rm -f
    echo "🗑️  Removed untracked test files"
else
    echo "ℹ️  No untracked test files found"
fi

# Check if .backup needs to be added to .gitignore
echo "📋 Checking .gitignore for .backup entry..."
if ! grep -q "^\.backup/$" .gitignore 2>/dev/null; then
    echo ".backup/" >> .gitignore
    echo "✅ Added .backup/ to .gitignore"
    
    # Commit .gitignore change
    git add .gitignore
    git commit -m "Add .backup/ to .gitignore for test file cleanup"
    echo "✅ Committed .gitignore update"
else
    echo "ℹ️  .backup/ already in .gitignore"
fi

# Generate tracked file candidate list (excluding specified patterns)
echo "📝 Generating tracked test file candidates list..."
git ls-files | grep -i test | \
    grep -v "\.backup/" | \
    grep -v "node_modules/" | \
    grep -v "vendor/" | \
    grep -v "\.git/" > "${BACKUP_DIR}/${TRACKED_LIST}"

TRACKED_COUNT=$(wc -l < "${BACKUP_DIR}/${TRACKED_LIST}")
echo "✅ Generated tracked test files list: ${BACKUP_DIR}/${TRACKED_LIST}"
echo "📊 Found ${TRACKED_COUNT} tracked files with 'test' in path"

# Summary report
echo ""
echo "🎯 CLEANUP SUMMARY"
echo "=================="
echo "Branch created: ${CLEANUP_BRANCH}"
echo "Previous branch: ${CURRENT_BRANCH}"
if [[ -n "${UNTRACKED_TEST_FILES}" ]]; then
    echo "Archive created: ${BACKUP_DIR}/${ARCHIVE_NAME}"
    echo "Untracked files archived: $(echo "${UNTRACKED_TEST_FILES}" | wc -l)"
fi
echo "Tracked files list: ${BACKUP_DIR}/${TRACKED_LIST}"
echo "Tracked files found: ${TRACKED_COUNT}"
echo ""
echo "✅ Cleanup process completed successfully!"
echo ""
echo "Next steps:"
echo "- Review tracked files in: ${BACKUP_DIR}/${TRACKED_LIST}"
echo "- Switch back to main branch: git checkout ${CURRENT_BRANCH}"
echo "- Merge cleanup branch if satisfied: git merge ${CLEANUP_BRANCH}"